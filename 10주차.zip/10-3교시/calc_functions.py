# 파이썬 계산기의 함수 모듈
    
# 팩토리얼 함수:
def factorial(n):
    return "factorial (!)"

# 로마 숫자로 변환하는 함수:
def to_roman(n):
    return "-> roman"

# 10진수를 2진수로 변환하는 함수:
def to_binary(n):
    return "-> binary"

# 2진수를 10진수로 변환하는 함수:
def from_binary(n):
    return "binary -> 10"
# 제곱 변환하는 함수:
def square(n):
    return n**2
