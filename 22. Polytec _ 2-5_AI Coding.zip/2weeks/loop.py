Python 3.9.4 (tags/v3.9.4:1f2e308, Apr  6 2021, 13:40:21) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> i = 0
result_even = 0
 
while i < 100:
    i = i + 1
    if i % 2 == 0:
        result_even = result_even + i


