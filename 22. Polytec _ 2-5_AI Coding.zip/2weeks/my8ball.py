# MyMagic8Ball

import random

# 답변을 입력해 봅시다.
ans1="go for it"
ans2="no way"
ans3="im not sure."
ans4="fear of the unknown."
ans5="it would be..!"
ans6="only you can!"
ans7="makes no difference to me?"
ans8="right choice."

print("MyMagic8Ball, welcome.")

# 사용자의 질문 얻기
question = input("advice.\n")

print("thinking..\n" * 4)

# 질문에 알맞은 답변을 하는 일에 randint() 함수를 활용합니다.
choice=random.randint(1, 8)
if choice==1:
    answer=ans1
elif choice==2:
    answer=ans2
elif choice==3:
    answer=ans3
elif choice==4:
    answer=ans4
elif choice==5:
    answer=ans5
elif choice==6:
    answer=ans6
elif choice==7:
    answer=ans7
else:
    answer=ans8

# 화면에 답변을 출력합니다.
print(answer)

input("\n\n마치려면 엔터 키를 누르세요.")
