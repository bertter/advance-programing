# MyMagic8Ball

import random

# write answers
ans1="go for it!"
ans2="no way, dude"
ans3="I'm not sure. Ask me again."
ans4="Fear of the unknown is what imprisons us."
ans5="It woud be madness to do that!"
ans6="Only you can save mankind!"
ans7="Make no difference to me, do or don't - whatever?"
ans8="Yes, the right choice."

print("MyMagic8Ball, welcome.")

# input
question = input("Ask me for advice then press Return to shake me.\n")

print("shaking...\n" * 4)

# use randint() function to select the correct answer.
choice=random.randint(1, 8)
if choice==1:
    answer=ans1
elif choice==2:
    answer=ans2
elif choice==3:
    answer=ans3
elif choice==4:
    answer=ans4
elif choice==5:
    answer=ans5
elif choice==6:
    answer=ans6
elif choice==7:
    answer=ans7
else:
    answer=ans8

# print the answer to the screen
print(answer)

input("\n\npress the return key to finish.")
